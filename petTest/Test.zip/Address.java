public class Address {

    public String num1;
    public String num2;
    public String num3;

    public Address() { }

    public Address(String num1, String num2, String num3) {
        this.num1 = num1;
        this.num2 = num2;
        this.num3 = num3;
    }
}
